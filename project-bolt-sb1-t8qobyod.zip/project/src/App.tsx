import { useEffect, useRef, useState } from 'react';
import {
  ArrowDown,
  ArrowUp,
  ArrowUpRight,
  BrainCircuit,
  Check,
  Code2,
  Database,
  Github,
  Instagram,
  Linkedin,
  Mail,
  Menu,
  ShoppingBag,
  Sparkles,
  Terminal,
  X,
} from 'lucide-react';

const skills = [
  { name: 'Python', level: 'Comfortable', icon: Terminal, tone: 'mint', blurb: 'Scripts, automation & data wrangling' },
  { name: 'SQL', level: 'Comfortable', icon: Database, tone: 'blue', blurb: 'Queries, joins & database design' },
  { name: 'C', level: 'Learning now', icon: Code2, tone: 'peach', blurb: 'Memory, pointers & low-level logic' },
  { name: 'AI tools', level: 'Learning now', icon: BrainCircuit, tone: 'yellow', blurb: 'Prompting, APIs & workflow automation' },
];

const navItems = ['About', 'Skills', 'Projects', 'Achievements'];

const stats = [
  { value: '3', label: 'Projects built' },
  { value: '4', label: 'Tools in toolkit' },
  { value: '∞', label: 'Curiosity level' },
];

const projects = [
  {
    number: '01',
    title: 'Retail Sales Insights',
    tagline: 'Data analysis dashboard',
    description: 'A Python + SQL pipeline that ingests 50K+ rows of retail transaction data, cleans and transforms it, then surfaces revenue trends, top-selling categories, and seasonal patterns through an interactive dashboard.',
    tech: ['Python', 'SQL', 'Pandas', 'Matplotlib'],
    accent: 'mint',
    highlights: ['50K+ rows processed', '12 interactive charts', 'Automated ETL pipeline'],
    icon: Database,
  },
  {
    number: '02',
    title: 'AI Study Companion',
    tagline: 'Smart learning assistant',
    description: 'An AI-powered tool that turns raw notes into structured summaries, generates practice quizzes, and adapts questions based on topic difficulty — built to help students study smarter, not harder.',
    tech: ['Python', 'AI Tools', 'NLP', 'FastAPI'],
    accent: 'peach',
    highlights: ['Auto-summary generation', 'Adaptive quiz engine', 'Topic difficulty scoring'],
    icon: BrainCircuit,
  },
  {
    number: '03',
    title: 'QuickBite',
    tagline: 'Frontend project brief',
    description: 'A planned modern, responsive food-ordering experience where users can browse restaurant categories, compare menu items, and build a cart with a clear running total.',
    tech: ['HTML', 'CSS', 'JavaScript', 'Responsive UI'],
    accent: 'yellow',
    highlights: ['Restaurant hero banner', 'Category-based browsing', 'Cart and total price flow'],
    icon: ShoppingBag,
  },
];

function useScrollProgress() {
  const [progress, setProgress] = useState(0);
  useEffect(() => {
    const onScroll = () => {
      const scrollTop = window.scrollY;
      const docHeight = document.documentElement.scrollHeight - window.innerHeight;
      setProgress(docHeight > 0 ? (scrollTop / docHeight) * 100 : 0);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener('scroll', onScroll);
  }, []);
  return progress;
}

function useActiveSection(ids: string[]) {
  const [active, setActive] = useState('');
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) setActive(entry.target.id);
        });
      },
      { rootMargin: '-30% 0px -60% 0px' },
    );
    ids.forEach((id) => {
      const el = document.getElementById(id);
      if (el) observer.observe(el);
    });
    return () => observer.disconnect();
  }, [ids]);
  return active;
}

function useReveal() {
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-revealed');
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: '0px 0px -60px 0px' },
    );
    document.querySelectorAll('[data-reveal]').forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);
}

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [showTop, setShowTop] = useState(false);
  const heroRef = useRef<HTMLDivElement>(null);

  const progress = useScrollProgress();
  const activeSection = useActiveSection(['top', 'skills', 'projects', 'achievements', 'contact']);
  useReveal();

  useEffect(() => {
    const onScroll = () => setShowTop(window.scrollY > 600);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const closeMenu = () => setMenuOpen(false);

  return (
    <div className="site-shell">
      <div className="scroll-progress" style={{ width: `${progress}%` }} />

      <header className={`site-header ${window.scrollY > 40 ? 'is-scrolled' : ''}`}>
        <a href="#top" className="brand" onClick={closeMenu}>
          <span className="brand-mark">K</span>
          <span>kashish<span className="brand-dot">.</span></span>
        </a>

        <nav className={menuOpen ? 'main-nav is-open' : 'main-nav'} aria-label="Main navigation">
          {navItems.map((item) => {
            const sectionId = item === 'About' ? 'top' : item.toLowerCase();
            return (
              <a
                key={item}
                href={`#${sectionId}`}
                onClick={closeMenu}
                className={activeSection === sectionId ? 'is-active' : ''}
              >
                {item}
                {activeSection === sectionId && <span className="nav-dot" />}
              </a>
            );
          })}
          <a href="#contact" className="nav-contact" onClick={closeMenu}>Let's talk <ArrowUpRight size={15} /></a>
        </nav>

        <button className="menu-toggle" aria-label={menuOpen ? 'Close menu' : 'Open menu'} onClick={() => setMenuOpen(!menuOpen)}>
          {menuOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </header>

      <main id="top" ref={heroRef}>
        <section className="hero section-grid">
          <div className="hero-copy">
            <p className="eyebrow" data-reveal><span className="eyebrow-line" /> available for learning & collaboration</p>
            <h1 data-reveal>Hi, I'm <span>Kashish.</span><br />I'm building my<br /><em>next chapter.</em></h1>
            <p className="hero-description" data-reveal>A curious learner exploring the space between code, data, and intelligent tools. I'm starting small, staying consistent, and enjoying the process.</p>
            <div className="hero-actions" data-reveal>
              <a className="button button-dark" href="#contact">Get in touch <ArrowUpRight size={17} /></a>
              <a className="text-link" href="#skills">Explore my skills <span>↓</span></a>
            </div>
            <div className="hero-stats" data-reveal>
              {stats.map((s) => (
                <div className="stat-item" key={s.label}>
                  <span className="stat-value">{s.value}</span>
                  <span className="stat-label">{s.label}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="hero-art" aria-label="Illustration of Kashish learning and building" data-reveal>
            <div className="art-circle circle-one" />
            <div className="art-circle circle-two" />
            <div className="code-card"><span className="code-dot red" /><span className="code-dot yellow" /><span className="code-dot green" /><div className="code-lines"><i /><i /><i /><i /></div></div>
            <div className="profile-orb"><span>K</span></div>
            <div className="floating-note note-top float-anim"><Sparkles size={17} /> keep learning</div>
            <div className="floating-note note-bottom float-anim-slow">01 <span>/ curious mind</span></div>
            <div className="art-caption">code · data · curiosity</div>
          </div>
          <a href="#top" className="scroll-indicator" aria-label="Scroll down" >
            <span className="scroll-mouse"><span className="scroll-wheel" /></span>
            <span className="scroll-text">scroll</span>
            <ArrowDown size={14} />
          </a>
        </section>

        <section className="intro-strip">
          <div className="section-label" data-reveal>01 / about</div>
          <div className="intro-content" data-reveal>
            <p className="section-kicker">A little about me</p>
            <h2>I'm at the beginning,<br /><span>and that's exciting.</span></h2>
            <p className="body-copy">I don't have a long list of achievements yet — I'm here to change that one project and one new concept at a time. Right now I'm learning how to think clearly with Python and SQL, building a foundation in C, and discovering how AI tools can make ideas move faster.</p>
            <div className="quote-line"><span>"</span><p>Progress over perfection, every single day.</p></div>
          </div>
        </section>

        <section className="skills-section" id="skills">
          <div className="section-label" data-reveal>02 / skills</div>
          <div className="skills-heading" data-reveal><div><p className="section-kicker">What I'm working with</p><h2>Tools in my<br /><span>toolbox.</span></h2></div><p className="heading-aside">The best skill is the willingness to keep learning. These are the tools I'm currently getting familiar with.</p></div>
          <div className="skills-grid">
            {skills.map(({ name, level, icon: Icon, tone, blurb }) => (
              <div className={`skill-card ${tone}`} key={name} data-reveal>
                <div className="skill-icon"><Icon size={23} strokeWidth={1.8} /></div>
                <div className="skill-body">
                  <h3>{name}</h3>
                  <p className="skill-level">{level}</p>
                  <p className="skill-blurb">{blurb}</p>
                </div>
                <Check className="skill-check" size={17} />
                <div className="skill-shine" />
              </div>
            ))}
          </div>
        </section>

        <section className="projects-section" id="projects">
          <div className="section-label" data-reveal>03 / projects</div>
          <div className="project-heading" data-reveal><div><p className="section-kicker">Things I've built</p><h2>Small steps.<br /><span>Real practice.</span></h2></div><p className="heading-aside">Three projects that combine data, code, and AI tools to solve practical problems. Each one taught me something new about building end-to-end.</p></div>
          <div className="projects-grid">
            {projects.map(({ number, title, tagline, description, tech, highlights, accent, icon: Icon }) => (
              <article className={`project-card ${accent}`} key={number} data-reveal>
                <div className="project-card-top">
                  <div className="project-number">{number}</div>
                  <div className="project-card-icon"><Icon size={26} strokeWidth={1.6} /></div>
                </div>
                <p className="project-tagline">{tagline}</p>
                <h3 className="project-title">{title}</h3>
                <p className="project-description">{description}</p>
                <ul className="project-highlights">
                  {highlights.map((h) => <li key={h}><Check size={14} /> {h}</li>)}
                </ul>
                <div className="project-tech">
                  {tech.map((t) => <span className="tech-pill" key={t}>{t}</span>)}
                </div>
                <a href="#contact" className="project-link">View details <ArrowUpRight size={15} /></a>
              </article>
            ))}
          </div>
        </section>

        <section className="achievement-section" id="achievements">
          <div className="section-label" data-reveal>04 / achievements</div>
          <div className="achievement-inner" data-reveal><div><p className="section-kicker">No trophies. Yet.</p><h2>The list is<br /><span>still open.</span></h2></div><div className="achievement-message"><div className="open-circle"><span>+</span></div><p>There are no big achievements to list right now, and I'm okay with that. I'm focused on learning deeply and making the next version of this section worth the wait.</p><a href="#contact" className="text-link">Be part of the journey <ArrowUpRight size={16} /></a></div></div>
        </section>

        <section className="contact-section" id="contact">
          <div className="contact-orbit orbit-a" /><div className="contact-orbit orbit-b" />
          <div className="section-label" data-reveal>05 / contact</div>
          <div className="contact-content" data-reveal><p className="section-kicker">Have an idea?</p><h2>Let's make<br /><em>something useful.</em></h2><p>Whether it's a learning opportunity, a collaboration, or just a good conversation about tech — I'd love to hear from you.</p><a className="email-link" href="mailto:kashishg7796@gmail.com"><Mail size={20} /> kashishg7796@gmail.com <ArrowUpRight size={18} /></a></div>
        </section>
      </main>

      <footer className="site-footer"><a href="#top" className="brand"><span className="brand-mark">K</span><span>kashish<span className="brand-dot">.</span></span></a><p>made with curiosity · 2026</p><div className="socials"><a href="mailto:kashishg7796@gmail.com" aria-label="Email"><Mail size={18} /></a><a href="#top" aria-label="LinkedIn"><Linkedin size={18} /></a><a href="#top" aria-label="GitHub"><Github size={18} /></a><a href="#top" aria-label="Instagram"><Instagram size={18} /></a></div></footer>

      <button
        className={`back-to-top ${showTop ? 'is-visible' : ''}`}
        onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
        aria-label="Back to top"
      >
        <ArrowUp size={20} />
      </button>
    </div>
  );
}

export default App;
